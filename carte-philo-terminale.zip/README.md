
# Carte interactive - Philosophie Terminale

Cette carte interactive permet d'explorer les 17 notions du programme de Terminale de philosophie à travers une carte cliquable. Chaque zone mène vers une fiche notionnelle simple.

## Utilisation

Ouvrir `index.html` dans un navigateur. Cliquer sur les zones de la carte pour accéder aux notions.

## Crédits

Prototype généré automatiquement pour usage pédagogique.
